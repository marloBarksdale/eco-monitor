import React, { useEffect } from 'react';
import SimulateRealTimeData from '../utils/SimulateRealTimeData';
import { SensorData } from '../types/SensorData';
import { DashboardState } from '../types/DashboardState';
import { useReducer } from 'react';
import Card from './Card';
import { useState } from 'react';
import FilterControls from './FilterControls';



const initialState: DashboardState = {
  data: []
};



type DashboardAction = {
  type: 'ADD_DATA';
  payload: SensorData[];
};


const dashboardReducer = (state: DashboardState, action: DashboardAction): DashboardState => {
 const combined = [...action.payload, ...state.data];
  combined.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  return { ...state, data: combined };
};




const Dashboard= () => {

const [state, dispatch] = useReducer(dashboardReducer, initialState);

const [filters, setFilters] = useState({
  temp: { min: 10, max: 40 },
  humidity: { min: 30, max: 90 },
  aqi: { min: 0, max: 200 }
});


useEffect(() => {
  const stopSimulation = SimulateRealTimeData(100, 1000, (updates) => {
    dispatch({ type: 'ADD_DATA', payload: updates });
  });

  return () => stopSimulation();
}, []);




const filteredData = state.data.filter((item) => {
  return (
    item.temperature >= filters.temp.min &&
    item.temperature <= filters.temp.max &&
    item.humidity >= filters.humidity.min &&
    item.humidity <= filters.humidity.max &&
    item.airQuality >= filters.aqi.min &&
    item.airQuality <= filters.aqi.max
  );
});


  return (
    <div>
      <h1>Eco-Monitor Dashboard</h1>
      <FilterControls filters={filters} setFilters={setFilters} />
     {filteredData.map((item) => (
  <Card key={`${item.sensorId}-${item.timestamp}`} data={item} />
))}
    </div>
  );
};

export default Dashboard;
