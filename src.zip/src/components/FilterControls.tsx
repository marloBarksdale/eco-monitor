import React, { useState } from 'react';
import './FilterControls.css';

interface Filters {
  temp: { min: number; max: number };
  humidity: { min: number; max: number };
  aqi: { min: number; max: number };
}

interface FilterControlsProps {
  filters: Filters;
  setFilters: React.Dispatch<React.SetStateAction<Filters>>;
}

const FilterControls = ({ filters, setFilters }: FilterControlsProps) => {
  const [tempMode, setTempMode] = useState<'all' | 'safe' | 'high' | 'custom'>('all');
  const [humidityMode, setHumidityMode] = useState<'all' | 'safe' | 'custom'>('all');
  const [aqiMode, setAqiMode] = useState<'all' | 'safe' | 'high' | 'custom'>('all');

  const applyPreset = (type: 'temp' | 'humidity' | 'aqi', mode: string) => {
    const newFilters = { ...filters };

    switch (type) {
      case 'temp':
        setTempMode(mode as any);
        if (mode === 'all') newFilters.temp = { min: 10, max: 40 };
        else if (mode === 'safe') newFilters.temp = { min: 20, max: 30 };
        else if (mode === 'high') newFilters.temp = { min: 30, max: 40 };
        break;
      case 'humidity':
        setHumidityMode(mode as any);
        if (mode === 'all') newFilters.humidity = { min: 30, max: 90 };
        else if (mode === 'safe') newFilters.humidity = { min: 40, max: 60 };
        break;
      case 'aqi':
        setAqiMode(mode as any);
        if (mode === 'all') newFilters.aqi = { min: 0, max: 200 };
        else if (mode === 'safe') newFilters.aqi = { min: 0, max: 50 };
        else if (mode === 'high') newFilters.aqi = { min: 100, max: 200 };
        break;
    }

    setFilters(newFilters);
  };

  const handleCustomSlider = (
  type: 'temp' | 'humidity' | 'aqi',
  bound: 'min' | 'max',
  value: number
) => {
  setFilters(prev => {
    const otherBound = bound === 'min' ? 'max' : 'min';
    const otherValue = prev[type][otherBound];

    const newValue =
      bound === 'min'
        ? Math.min(value, otherValue) // min can't exceed max
        : Math.max(value, otherValue); // max can't go below min

    return {
      ...prev,
      [type]: {
        ...prev[type],
        [bound]: newValue
      }
    };
  });
};


  return (
    <div className="filter-controls">
      <h2>Sensor Filters</h2>

      {/* Temperature */}
      <div className="filter-group">
        <label>Temperature ({filters.temp.min}°C – {filters.temp.max}°C)</label>
        <div className="preset-buttons">
          <button onClick={() => applyPreset('temp', 'all')} className={tempMode === 'all' ? 'active' : ''}>All</button>
          <button onClick={() => applyPreset('temp', 'safe')} className={tempMode === 'safe' ? 'active' : ''}>Safe (20–30)</button>
          <button onClick={() => applyPreset('temp', 'high')} className={tempMode === 'high' ? 'active' : ''}>High (&gt;30)</button>
          <button onClick={() => applyPreset('temp', 'custom')} className={tempMode === 'custom' ? 'active' : ''}>Custom</button>
        </div>
        {tempMode === 'custom' && (
          <div className="slider-pair">
            <input type="range" min="10" max="40" value={filters.temp.min}
              onChange={e => handleCustomSlider('temp', 'min', Number(e.target.value))} />
            <input type="range" min="10" max="40" value={filters.temp.max}
              onChange={e => handleCustomSlider('temp', 'max', Number(e.target.value))} />
          </div>
        )}
      </div>

      {/* Humidity */}
      <div className="filter-group">
        <label>Humidity ({filters.humidity.min}% – {filters.humidity.max}%)</label>
        <div className="preset-buttons">
          <button onClick={() => applyPreset('humidity', 'all')} className={humidityMode === 'all' ? 'active' : ''}>All</button>
          <button onClick={() => applyPreset('humidity', 'safe')} className={humidityMode === 'safe' ? 'active' : ''}>Safe (40–60)</button>
          <button onClick={() => applyPreset('humidity', 'custom')} className={humidityMode === 'custom' ? 'active' : ''}>Custom</button>
        </div>
        {humidityMode === 'custom' && (
          <div className="slider-pair">
            <input type="range" min="30" max="90" value={filters.humidity.min}
              onChange={e => handleCustomSlider('humidity', 'min', Number(e.target.value))} />
            <input type="range" min="30" max="90" value={filters.humidity.max}
              onChange={e => handleCustomSlider('humidity', 'max', Number(e.target.value))} />
          </div>
        )}
      </div>

      {/* AQI */}
      <div className="filter-group">
        <label>Air Quality Index (AQI) ({filters.aqi.min} – {filters.aqi.max})</label>
        <div className="preset-buttons">
          <button onClick={() => applyPreset('aqi', 'all')} className={aqiMode === 'all' ? 'active' : ''}>All</button>
          <button onClick={() => applyPreset('aqi', 'safe')} className={aqiMode === 'safe' ? 'active' : ''}>Good (0–50)</button>
          <button onClick={() => applyPreset('aqi', 'high')} className={aqiMode === 'high' ? 'active' : ''}>Unhealthy (&gt;100)</button>
          <button onClick={() => applyPreset('aqi', 'custom')} className={aqiMode === 'custom' ? 'active' : ''}>Custom</button>
        </div>
        {aqiMode === 'custom' && (
          <div className="slider-pair">
            <input type="range" min="0" max="200" value={filters.aqi.min}
              onChange={e => handleCustomSlider('aqi', 'min', Number(e.target.value))} />
            <input type="range" min="0" max="200" value={filters.aqi.max}
              onChange={e => handleCustomSlider('aqi', 'max', Number(e.target.value))} />
          </div>
        )}
      </div>
    </div>
  );
};

export default FilterControls;
