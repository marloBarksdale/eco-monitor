import { SensorData } from './SensorData';

export interface DashboardState {
  data: SensorData[];
}